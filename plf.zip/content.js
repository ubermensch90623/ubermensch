(function () {
  "use strict";

  const core = globalThis.PortalLifeFilterCore;
  if (!core) return;

  const hostname = location.hostname.toLowerCase();
  const pathname = location.pathname;
  const isDaum = hostname.endsWith("daum.net");
  const isNate = hostname.endsWith("nate.com");
  const isYonhap = hostname.endsWith("yna.co.kr");
  const isZum = hostname.endsWith("zum.com");
  const isGoogleNews = hostname === "news.google.com";
  const isMsn = hostname.endsWith("msn.com");
  const isBingNews = hostname.endsWith("bing.com") && pathname.startsWith("/news");
  const isNaverNewsSearch = hostname === "search.naver.com" && /(?:^|[?&])where=news(?:&|$)/.test(location.search || "");
  const KNOWN_NEWS_HOST_SUFFIXES = Object.freeze([
    "chosun.com", "joongang.co.kr", "donga.com", "hani.co.kr", "khan.co.kr",
    "hankyung.com", "mk.co.kr", "mt.co.kr", "edaily.co.kr", "seoul.co.kr",
    "newsis.com", "news1.kr", "ytn.co.kr", "sbs.co.kr", "imbc.com", "kbs.co.kr",
    "jtbc.co.kr", "mbn.co.kr", "tvchosun.com", "ichannela.com", "segye.com",
    "kmib.co.kr", "munhwa.com", "heraldcorp.com", "asiae.co.kr", "fnnews.com",
    "ajunews.com", "etnews.com", "zdnet.co.kr", "nocutnews.co.kr", "ohmynews.com",
    "pressian.com", "hankookilbo.com", "sisajournal.com", "sisain.co.kr",
    "economist.co.kr", "inews24.com", "ddaily.co.kr", "bloter.net", "bizwatch.co.kr",
    "newspim.com", "dealsite.co.kr", "thebell.co.kr", "mediatoday.co.kr", "dt.co.kr",
    "digitaltoday.co.kr", "newdaily.co.kr", "upinews.kr", "ebn.co.kr",
    "sedaily.com", "etoday.co.kr", "sidae.com", "wowtv.co.kr", "businesspost.co.kr",
    "ceoscoredaily.com", "enewstoday.co.kr", "greened.kr", "viva100.com"
  ]);
  const BLOCKED_ENTERTAINMENT_HOST_SUFFIXES = Object.freeze([
    "joynews24.com", "isplus.com", "osen.co.kr", "sportsseoul.com", "starnewskorea.com",
    "xportsnews.com", "newsen.com", "mydaily.co.kr", "tvreport.co.kr", "dispatch.co.kr",
    "heraldpop.com", "topstarnews.net", "wikitree.co.kr"
  ]);
  const isKnownPublisher = KNOWN_NEWS_HOST_SUFFIXES.some((suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`));
  const isBlockedEntertainmentHost = BLOCKED_ENTERTAINMENT_HOST_SUFFIXES.some((suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`));
  const isNaverSports = hostname === "sports.naver.com" || hostname === "m.sports.naver.com";
  const isNaverWfootball = isNaverSports && pathname.startsWith("/wfootball/");
  const search = location.search || "";
  const isNaverArticlePage =
    hostname === "n.news.naver.com" && pathname.includes("/article/");
  const isYonhapArticlePage = isYonhap && pathname.startsWith("/view/");
  const isNaverSportsArticlePage = isNaverWfootball && pathname.includes("/article/");
  const isKnownPublisherArticlePage = (isKnownPublisher || isMsn) && isKnownPublisherArticlePath(hostname, pathname, search);
  const isArticlePage =
    isNaverArticlePage ||
    isYonhapArticlePage ||
    isNaverSportsArticlePage ||
    isKnownPublisherArticlePage ||
    (hostname === "v.daum.net" && pathname.startsWith("/v/")) ||
    ((hostname === "news.nate.com" || hostname === "m.news.nate.com") && pathname.startsWith("/view/"));
  const isFeedPage =
    hostname === "www.naver.com" || hostname === "news.naver.com" ||
    hostname === "m.news.naver.com" || hostname === "m.naver.com" || hostname === "media.naver.com" || isNaverNewsSearch ||
    hostname === "www.daum.net" || hostname === "news.daum.net" ||
    hostname === "www.nate.com" || hostname === "m.nate.com" ||
    ((hostname === "news.nate.com" || hostname === "m.news.nate.com") && !pathname.startsWith("/view/")) ||
    (isYonhap && !isYonhapArticlePage) ||
    isZum ||
    isGoogleNews ||
    isMsn || isBingNews ||
    (isKnownPublisher && !isKnownPublisherArticlePage) ||
    (isNaverWfootball && !isNaverSportsArticlePage);

  const portalHome = isDaum ? "https://www.daum.net/" : isNate ? "https://www.nate.com/" : isYonhap ? "https://www.yna.co.kr/" : isZum ? "https://zum.com/" : isGoogleNews ? "https://news.google.com/home?hl=ko&gl=KR&ceid=KR:ko" : isMsn ? "https://www.msn.com/ko-kr" : isBingNews ? "https://www.bing.com/news?cc=kr&setlang=ko" : isKnownPublisher ? `https://${hostname}/` : isNaverWfootball ? "https://m.sports.naver.com/wfootball/news" : "https://www.naver.com/";
  const fullyBlocked =
    hostname === "entertain.naver.com" || hostname === "m.entertain.naver.com" ||
    hostname === "in.naver.com" || (hostname === "m.naver.com" && pathname.startsWith("/shorts")) ||
    ((hostname === "sports.naver.com" || hostname === "m.sports.naver.com") && /baseball|kbaseball|wbaseball/i.test(pathname)) ||
    hostname === "entertain.daum.net" || hostname === "pann.nate.com" || hostname === "m.pann.nate.com" ||
    hostname === "tv.nate.com" || hostname === "m.tv.nate.com" || isBlockedEntertainmentHost ||
    ((hostname === "news.nate.com" || hostname === "m.news.nate.com") && pathname.startsWith("/ent/")) ||
    (hostname === "news.zum.com" && pathname === "/front" && /(?:^|[?&])c=(?:05|06)(?:&|$)/.test(search));

  if (fullyBlocked) {
    location.replace(portalHome);
    return;
  }

  if (isArticlePage) document.documentElement.classList.add("plf-article-pending", "plf-article-active");
  if (isFeedPage) document.documentElement.classList.add("plf-feed-active");
  if (isKnownPublisher || isMsn) document.documentElement.classList.add("plf-news-probe");

  let settings = core.DEFAULTS;
  let activeArticleDetected = isArticlePage;

  function getSettings() {
    return new Promise((resolve) => {
      if (!chrome?.storage?.sync) return resolve(core.DEFAULTS);
      chrome.storage.sync.get({ portalLifeFilter: core.DEFAULTS }, (result) => {
        resolve(Object.assign({}, core.DEFAULTS, result.portalLifeFilter || {}));
      });
    });
  }

  function isKnownPublisherArticlePath(targetHost, targetPath, targetSearch) {
    const host = String(targetHost || "").toLowerCase();
    const value = `${targetPath || ""}${targetSearch || ""}`;
    if (host.endsWith("msn.com")) return /\/(?:news|money|sports)\/.+\/(?:ar|vi)-[a-z0-9]+/i.test(value);
    if (host.endsWith("chosun.com")) return /\/\d{4}\/\d{2}\/\d{2}\/[a-z0-9]{16,}\/?(?:\?|$)/i.test(value) || /\/news\/\d+/i.test(value);
    if (host.endsWith("joongang.co.kr")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("donga.com")) return /\/article\/(?:all\/)?\d+/i.test(value);
    if (host.endsWith("hani.co.kr")) return /\/arti\/.+\/\d+\.html/i.test(value);
    if (host.endsWith("khan.co.kr")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("hankyung.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("mk.co.kr")) return /\/news\/.+\/\d+/i.test(value);
    if (host.endsWith("mt.co.kr")) return /mtview\.php|\/view\/.+\d+/i.test(value) && /(?:no|id|seq)=?\d*/i.test(value);
    if (host.endsWith("edaily.co.kr")) return /\/news\/read/i.test(value) && /newsid=/i.test(value);
    if (host.endsWith("seoul.co.kr")) return /\/news\/.+\/\d{4}\/\d{2}\/\d{2}\//i.test(value) || /\/news\/newsview\.php/i.test(value);
    if (host.endsWith("newsis.com")) return /\/view\/NISX/i.test(value) || /\/view\/\?id=NISX/i.test(value);
    if (host.endsWith("news1.kr")) return /\/articles\/\d+/i.test(value);
    if (host.endsWith("ytn.co.kr")) return /\/_ln\/\d+_\d+/i.test(value);
    if (host.endsWith("sbs.co.kr")) return /\/news\/endpage\.do/i.test(value) && /news_?id=/i.test(value);
    if (host.endsWith("imbc.com")) return /\/article\/\d+_\d+\.html/i.test(value);
    if (host.endsWith("kbs.co.kr")) return /\/view\/view\.do/i.test(value) && /ncd=\d+/i.test(value);
    if (host.endsWith("jtbc.co.kr")) return /\/article\/NB\d+/i.test(value);
    if (host.endsWith("mbn.co.kr")) return /\/news\/(?:all|economy|politics|society|world|culture|sports|entertainment)\/\d+/i.test(value);
    if (host.endsWith("tvchosun.com")) return /\/site\/data\/html_dir\/.+\.html/i.test(value);
    if (host.endsWith("ichannela.com")) return /\/news\/(?:detail|main)\//i.test(value) && /\d+/.test(value);
    if (host.endsWith("segye.com")) return /\/newsview\/\d+/i.test(value);
    if (host.endsWith("kmib.co.kr")) return /\/article\/view\.asp/i.test(value) && /arcid=/i.test(value);
    if (host.endsWith("munhwa.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("heraldcorp.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("asiae.co.kr")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("fnnews.com")) return /\/news\/\d+/i.test(value);
    if (host.endsWith("ajunews.com")) return /\/view\/\d+/i.test(value);
    if (host.endsWith("etnews.com")) return /\/\d+/i.test(value) && /\/news\//i.test(value);
    if (host.endsWith("zdnet.co.kr")) return /\/view\/?\?no=\d+/i.test(value);
    if (host.endsWith("nocutnews.co.kr")) return /\/news\/\d+/i.test(value);
    if (host.endsWith("ohmynews.com")) return /\/NWS_Web\/View\/at_pg\.aspx/i.test(value) && /CNTN_CD=/i.test(value);
    if (host.endsWith("pressian.com")) return /\/pages\/articles\/\d+/i.test(value);
    if (host.endsWith("hankookilbo.com")) return /\/News\/Read\/[A-Z0-9]+/i.test(value);
    if (host.endsWith("sisajournal.com") || host.endsWith("sisain.co.kr") || host.endsWith("bloter.net") || host.endsWith("mediatoday.co.kr")) {
      return /\/news\/articleView\.html/i.test(value) && /idxno=\d+/i.test(value);
    }
    if (host.endsWith("economist.co.kr")) return /\/article\/view\/[a-z0-9]+/i.test(value);
    if (host.endsWith("inews24.com")) return /\/view\/\d+/i.test(value);
    if (host.endsWith("ddaily.co.kr")) return /\/(?:page\/view|news\/article)\/\d+/i.test(value);
    if (host.endsWith("bizwatch.co.kr")) return /\/article\/.+\/\d{4}\/\d{2}\/\d{2}\/\d+/i.test(value);
    if (host.endsWith("newspim.com")) return /\/news\/view\/\d+/i.test(value);
    if (host.endsWith("dealsite.co.kr")) return /\/articles\/\d+/i.test(value);
    if (host.endsWith("thebell.co.kr")) return /\/front\/newsview\.asp/i.test(value) && /key=\d+/i.test(value);
    if (host.endsWith("sedaily.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("etoday.co.kr")) return /\/news\/view\/\d+/i.test(value);
    if (host.endsWith("sidae.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("wowtv.co.kr")) return /\/NewsCenter\/News\/Read/i.test(value) && /articleId=[A-Z0-9]+/i.test(value);
    if (host.endsWith("businesspost.co.kr")) return /\/(?:BP)?/i.test(value) && /command=article_view/i.test(value) && /num=\d+/i.test(value);
    if (host.endsWith("ceoscoredaily.com")) return /\/page\/view\/\d+/i.test(value);
    if (host.endsWith("enewstoday.co.kr") || host.endsWith("greened.kr")) {
      return /\/news\/articleView\.html/i.test(value) && /idxno=\d+/i.test(value);
    }
    if (host.endsWith("viva100.com")) return /\/article\/\d+/i.test(value);
    if (host.endsWith("dt.co.kr") || host.endsWith("digitaltoday.co.kr") || host.endsWith("newdaily.co.kr") || host.endsWith("upinews.kr") || host.endsWith("ebn.co.kr")) {
      return /articleView\.html|\/article\/|\/news\/view|\/news\/articleView/i.test(value) && /\d{5,}/.test(value);
    }
    return false;
  }

  function isKnownPublisherArticleUrl(value) {
    try {
      const target = new URL(value, location.href);
      const knownHost = KNOWN_NEWS_HOST_SUFFIXES.some((suffix) => target.hostname === suffix || target.hostname.endsWith(`.${suffix}`));
      return (knownHost || target.hostname.endsWith("msn.com")) &&
        isKnownPublisherArticlePath(target.hostname, target.pathname, target.search);
    } catch (_) {
      return false;
    }
  }

  function isBlockedEntertainmentUrl(value) {
    try {
      const target = new URL(value, location.href);
      return BLOCKED_ENTERTAINMENT_HOST_SUFFIXES.some((suffix) =>
        target.hostname === suffix || target.hostname.endsWith(`.${suffix}`)
      );
    } catch (_) {
      return false;
    }
  }

  function isPublisherContentAnchor(anchor) {
    if (!(isKnownPublisher || isNaverNewsSearch) || anchor.closest?.("header, nav, footer, [role='navigation']")) return false;
    const label = (anchor.innerText || anchor.textContent || "").replace(/\s+/g, " ").trim();
    if (label.length < 8) return false;
    try {
      const target = new URL(anchor.href, location.href);
      if (!/^https?:$/.test(target.protocol)) return false;
      if (isNaverNewsSearch && !target.hostname.endsWith("naver.com")) return true;
    } catch (_) {
      return false;
    }
    return Boolean(anchor.closest?.(
      "article, main li, [class*='article'], [class*='news-item'], [class*='news_item'], " +
      "[class*='news-card'], [class*='news_card'], [class*='headline'], [class*='story'], [class*='card']"
    ));
  }

  function articleTitle() {
    const selectors = ["#title_area span", ".media_end_head_headline", ".newsct_article h2", ".title-article01 h1", "h1.tit01", ".tit_view", ".head_view h3", "#articleTitle", ".articleSubject", "main h1", "main h2"];
    for (const selector of selectors) {
      const text = document.querySelector(selector)?.textContent?.trim();
      if (text) return text;
    }
    return document.title.replace(/\s*[:|-]\s*(네이버 뉴스|다음뉴스|네이트 뉴스).*$/i, "").trim();
  }

  function detectStructuredArticle() {
    if (!(isKnownPublisher || isMsn)) return false;
    const openGraphType = document.querySelector('meta[property="og:type"], meta[name="og:type"]')?.content || "";
    if (/^(?:article|news(?:article)?)$/i.test(openGraphType.trim())) return true;
    return [...document.querySelectorAll('script[type="application/ld+json"]')]
      .some((script) => /["']@type["']\s*:\s*["'](?:NewsArticle|Article|ReportageNewsArticle)["']/i.test(script.textContent || ""));
  }

  function isGoogleNewsArticleUrl(value) {
    if (!isGoogleNews) return false;
    try {
      const target = new URL(value, location.href);
      return target.href.includes("news.google.com/read/") || target.href.includes("news.google.com/articles/");
    } catch (_) {
      return false;
    }
  }

  function googleNewsCard(anchor) {
    if (!isGoogleNews) return null;
    let node = anchor.parentElement;
    let fallback = null;
    for (let depth = 0; node && node !== document.body && depth < 9; depth += 1, node = node.parentElement) {
      if (node.tagName === "ARTICLE") return node;
      if (!fallback && node.tagName === "C-WIZ") fallback = node;
      const textLength = (node.textContent || "").length;
      const readLinks = [...node.querySelectorAll("a[href]")].filter((link) => isGoogleNewsArticleUrl(link.href)).length;
      if (node.querySelector("time") && readLinks >= 1 && readLinks <= 6 && textLength <= 2500) return node;
    }
    return fallback;
  }

  function nearbyText(anchor) {
    const googleCard = googleNewsCard(anchor);
    if (googleCard) return (googleCard.textContent || "").slice(0, 1200);
    const card = anchor.closest("li, article, .comp_news_feed, .cjs_news_card, .sa_item, .item_news, .item_issue, .hero-news, .news-list-item, .content-card-container, .na_card_wrp, [class*='news_item'], [class*='news_card']");
    return (card?.textContent || anchor.textContent || "").slice(0, 1200);
  }

  function safeCard(anchor) {
    const googleCard = googleNewsCard(anchor);
    if (googleCard) return googleCard;
    const candidates = [
      anchor.closest(".hero-news"), anchor.closest(".news-list-item"),
      anchor.closest(".content-card-container"), anchor.closest(".na_card_wrp"),
      anchor.closest("li"), anchor.closest("article"), anchor.closest("[class*='news_item']"),
      anchor.closest("[class*='news_card']"), anchor.closest(".sa_item"), anchor.closest(".item_news"),
      anchor.closest(".item_issue")
    ].filter(Boolean);
    for (const node of candidates) {
      const links = node.querySelectorAll("a[href]").length;
      if (links <= 8 && (node.textContent || "").length <= 1800) return node;
    }
    return anchor;
  }

  function isArticleRecommendationAnchor(anchor) {
    if (!activeArticleDetected || anchor.closest?.("header, nav, footer, [role='navigation']")) return false;
    const href = anchor.href || "";
    if (/youtube\.com\/(?:watch|shorts)|youtu\.be\//i.test(href)) return true;
    return Boolean(anchor.closest?.(
      "aside, [class*='recommend'], [class*='related'], [class*='popular'], [class*='ranking'], " +
      "[class*='most-view'], [class*='hot-click'], [class*='hot_topic'], [class*='issue'], " +
      "[class*='clip'], [class*='shorts'], .w_article_side, .view-hot-click, .side-most-viewed"
    ));
  }

  function hideBlockedNode(node) {
    if (!node) return;
    node.classList.add("plf-blocked");
    node.dataset.plfBlocked = "true";
    // Document stylesheets do not cross a Shadow DOM boundary (MSN cards use one).
    if (node.style) {
      node.style.setProperty("display", "none", "important");
      node.style.setProperty("visibility", "hidden", "important");
    }
  }

  function looksLikeArticle(anchor) {
    const href = anchor.href || "";
    if (isArticleRecommendationAnchor(anchor)) return true;
    if (isKnownPublisherArticleUrl(href) || isBlockedEntertainmentUrl(href) || isPublisherContentAnchor(anchor)) return true;
    if (isGoogleNews) return isGoogleNewsArticleUrl(href);
    if (isMsn) {
      return isKnownPublisherArticleUrl(href) || Boolean(anchor.closest?.(".hero-news, .news-list-item, .content-card-container, [class*='card']"));
    }
    if (isBingNews) {
      if (anchor.closest?.("header, nav, footer, [role='navigation']")) return false;
      return Boolean(anchor.closest?.(".news_fbwcard, .na_card_wrp, .rns_card, [class*='news-card']"));
    }
    if (isKnownPublisher) {
      if (anchor.closest?.("header, nav, footer, [role='navigation']")) return false;
      return isKnownPublisherArticleUrl(href);
    }
    if (isZum) {
      if (anchor.closest?.("header, nav, footer, [role='navigation']")) return false;
      try {
        const target = new URL(href, location.href);
        if (!/^https?:$/.test(target.protocol)) return false;
        if (target.hostname.endsWith("zum.com")) {
          return target.hostname === "news.zum.com" && /\/article|\/view/.test(target.pathname);
        }
        return true;
      } catch (_) {
        return false;
      }
    }
    return (href.includes("n.news.naver.com/") && href.includes("/article/")) ||
      (href.includes("news.naver.com/") && (href.includes("aid=") || href.includes("article"))) ||
      href.includes("entertain.naver.com/") || href.includes("v.daum.net/v/") ||
      href.includes("sports.naver.com/") || href.includes("m.sports.naver.com/") ||
      href.includes("news.daum.net/") || href.includes("news.nate.com/view/") ||
      href.includes("news.nate.com/ent/") || href.includes("pann.nate.com/") ||
      href.includes("yna.co.kr/view/");
  }

  function mark(anchor, verdict) {
    anchor.dataset.plfProcessed = "true";
    anchor.dataset.plfReason = verdict.reason;
    if (verdict.blocked) {
      const card = safeCard(anchor);
      hideBlockedNode(card);
      if (settings.diagnostics) card.dataset.plfReason = verdict.reason;
    } else {
      anchor.classList.add("plf-allowed");
    }
  }

  function processAnchor(anchor) {
    if (!(anchor instanceof HTMLAnchorElement) || !looksLikeArticle(anchor)) return;
    if (anchor.dataset.plfProcessed === "true") return;
    anchor.classList.add("plf-candidate");
    const sportsHeadline = isNaverWfootball
      ? anchor.querySelector("em, strong, [class*='title']")?.textContent
      : "";
    const title = (sportsHeadline || anchor.innerText || anchor.textContent || "").replace(/\s+/g, " ").trim();
    if (isGoogleNews && title.length < 5) {
      anchor.dataset.plfProcessed = "true";
      anchor.dataset.plfReason = "google-news-non-title-link";
      return;
    }
    if (title.length < 5) return mark(anchor, { blocked: true, reason: "unclassified-short" });
    const classifySettings = isNaverWfootball
      ? Object.assign({}, settings, { sportsFeed: true, strictWhitelistOnFeeds: false })
      : isGoogleNews
        ? Object.assign({}, settings, { strictWhitelistOnFeeds: false })
        : settings;
    mark(anchor, core.classify(title, nearbyText(anchor), classifySettings));
  }

  function hideNoiseSections() {
    if (!settings.hideRecommendationFeed) return;
    const genericNoiseSelectors = [
      "[class*='recommend-news']", "[class*='recommend_news']", "[class*='recommended-news']", "[class*='recommended_news']",
      "[class*='most-viewed']", "[class*='most_viewed']", "[class*='most-read']", "[class*='most_read']",
      "[class*='ranking-news']", "[class*='ranking_news']", "[class*='popular-news']", "[class*='popular_news']",
      "[class*='hot-issue']", "[class*='hot_issue']", "[class*='hotissue']", "[class*='hot-click']", "[class*='hot_click']",
      "[class*='short-form']", "[class*='short_form']", "[class*='shortform']", "[class*='shorts']",
      "[class*='clip-list']", "[class*='clip_list']", "[class*='clip-section']", "[class*='clip_section']"
    ];
    document.querySelectorAll(genericNoiseSelectors.join(", ")).forEach((node) => node.classList.add("plf-blocked"));
    if (hostname === "www.naver.com") {
      document.querySelector("#feed")?.classList.add("plf-blocked");
      document.querySelector("[aria-label='추천 관심사']")?.classList.add("plf-blocked");
    }
    if (hostname === "www.daum.net") {
      document.querySelector(".board_enter")?.classList.add("plf-blocked");
      document.querySelector("#interestTitle")?.closest(".board_g")?.classList.add("plf-blocked");
      document.querySelectorAll(".box_ranking, .board_sports, .board_interest").forEach((node) => node.classList.add("plf-blocked"));
    }
    if (hostname === "www.nate.com") {
      document.querySelectorAll("#newstab2, #newstab3, #newstab5, #news_area .isKeyword, #divContentsUpper").forEach((node) => node.classList.add("plf-blocked"));
    }
    if (isYonhap) {
      [
        ".main-hotnews01", ".box-hotnews01", ".main-issue01", ".box-editors-video01",
        ".box-ranking-news01", ".box-long-stay01", ".box-digital-news01", ".box-ynalounge01",
        ".main-ent01", ".main-sports01", ".main-most-news01"
      ].forEach((selector) => document.querySelectorAll(selector).forEach((node) => node.classList.add("plf-blocked")));
    }
    if (isZum) {
      document.querySelectorAll(".issue_keywords, .home_ranking_news").forEach((node) => node.classList.add("plf-blocked"));
      document.querySelectorAll('a[href*="front?c=05"], a[href*="front?c=06"]').forEach((node) => node.classList.add("plf-blocked"));
    }
    if (isNaverWfootball) {
      [
        "[class*='Home_comp_issue_pick']",
        "[class*='Home_comp_main_news']",
        "[class*='Home_comp_open_talk']",
        "[class*='Home_comp_brand_trend_story']"
      ].forEach((selector) => document.querySelectorAll(selector).forEach((node) => node.classList.add("plf-blocked")));
      document.querySelectorAll('a[href*="m.naver.com/shorts"], a[href*="/community/issuetalk"], a[href*="talks.naver.com"]').forEach((node) => {
        const card = node.closest("li, article, [class*='_template_item'], [class*='_template_body_item'], [class*='Home_item']");
        (card || node).classList.add("plf-blocked");
      });
    }
    if (isNaverArticlePage) {
      [
        ".outside_area", "#_FEED_CARD_LEFT_OUTER_AFTER",
        ".media_end_linked", ".related_issue", ".feed_wrapper"
      ].forEach((selector) => document.querySelectorAll(selector).forEach((node) => node.classList.add("plf-blocked")));
    }
    if (activeArticleDetected) {
      [
        ".view-hot-click", ".side-most-viewed", ".w_article_side",
        ".hot_news.popular_wrap", ".hot_news.category_wrap"
      ].forEach((selector) => document.querySelectorAll(selector).forEach((node) => node.classList.add("plf-blocked")));
    }
    if (hostname === "media.naver.com") {
      [
        "#ShortForm", ".press_shortform", ".press_ranking_news",
        "#Broadcast", ".press_news.as_broadcast"
      ].forEach((selector) => document.querySelectorAll(selector).forEach((node) => node.classList.add("plf-blocked")));
      document.querySelectorAll('a[href*="/shortform"], a[href*="/ranking"], a[href*="/live"]').forEach((node) => node.classList.add("plf-blocked"));
      document.querySelectorAll("h1, h2, h3, h4, [class*='title']").forEach((heading) => {
        const headingText = (heading.textContent || "").replace(/\s+/g, " ").trim();
        if (!/(클립|랭킹 뉴스|핫!클릭|핫클릭|방송뉴스)$/.test(headingText)) return;
        heading.closest("._CURATION_CARD")?.classList.add("plf-blocked");
      });
    }
    const labels = new Set(["엔터", "연예", "연예톡", "아이돌24", "쇼핑투데이", "판", "TV", "쇼츠", "야구", "프로야구"]);
    const extraBlockedLabels = new Set([
      "화제의 사진/영상", "화제의 사진·영상", "화제의 사진과 영상", "화제의 사진", "화제의 영상",
      "오늘의 사건/사고", "오늘의 사건·사고", "오늘의 사건 사고", "스포츠/엔터", "스포츠·엔터",
      "트렌드", "핫클릭", "핫클릭 이슈", "이슈", "이슈 NOW", "이슈NOW", "핫뉴스", "랭킹뉴스",
      "오래 머문 뉴스", "Shorts", "에디터스 픽", "연합 마이뉴스",
      "많이 본 뉴스", "사람들이 많이 본 뉴스", "실시간 랭킹 기사", "종합랭킹", "Top랭킹",
      "실시간 이슈 키워드", "AI 이슈 트렌드", "AI 이슈트렌드", "언론사별 가장 많이 본 뉴스",
      "추천 Pick!", "에디터 추천", "에디터 추천뉴스", "AI 추천 뉴스", "추천 주요뉴스", "이 시각 추천 뉴스",
      "더중앙플러스 추천 시리즈", "더중앙플러스 인기 콘텐트", "핫이슈", "검색폭발 이슈키워드",
      "연예 스포츠", "SBS연예뉴스", "이슈 플레이", "추천 프로그램",
      "클립 인기 TOP 랭킹", "웹툰 인기 급상승", "인기/신규서비스", "추천뉴스", "추천 검색어",
      "라이브 이슈", "오늘의 핫이슈", "이슈체크", "오늘의 사건사고", "많이 읽은 기사",
      "많이 읽은 기사 종합 연예스포츠", "문화·연예", "연예·스포츠", "포토·영상",
      "구독한 이슈", "이슈투데이", "ISSUE Today", "오늘의 핫 클릭", "모닝 핫토픽",
      "AI 핫트렌드", "스포츠머그", "이 기사를 추천합니다", "오늘의동영상", "오늘의 동영상",
      "추천 상품", "추천상품", "매매신호 (랭킹100)", "매매신호", "Ditta 핫이슈",
      "뉴스&이슈", "뉴스 & 이슈", "핫이슈 칼럼", "방송·연예", "방송/연예"
    ]);
    const zumBlockedLabels = new Set(["스타랭킹", "인기 포스트", "AI 이슈트렌드", "웹툰 / 웹소설", "영상뉴스"]);
    const naverPressBlockedLabels = new Set(["클립", "랭킹", "많이 본 랭킹 뉴스", "댓글 많은 랭킹 뉴스"]);
    document.querySelectorAll("a, button, [role='tab'], [role='menuitem']").forEach((node) => {
      const label = (node.textContent || "").replace(/\s+/g, " ").trim();
      const normalizedLabel = label.replace(/^#+\s*/, "");
      const blockedPressLabel = hostname === "media.naver.com" && naverPressBlockedLabels.has(normalizedLabel);
      if (labels.has(label) || extraBlockedLabels.has(normalizedLabel) || zumBlockedLabels.has(normalizedLabel) || blockedPressLabel) node.classList.add("plf-blocked");
    });
    const blockedModules = ["오늘의 사건/사고", "오늘의 사건 사고", "연예", "야구", "프로야구"];
    blockedModules.push(...extraBlockedLabels);
    blockedModules.push(...zumBlockedLabels);
    if (hostname === "media.naver.com") blockedModules.push(...naverPressBlockedLabels);
    document.querySelectorAll("h1, h2, h3, h4, strong, em, b, [class*='title']").forEach((heading) => {
      const label = (heading.textContent || "").replace(/\s+/g, " ").trim().replace(/^#+\s*/, "");
      const isPressNoiseHeading = hostname === "media.naver.com" && /(클립|랭킹 뉴스)$/.test(label);
      const isGenericNoiseHeading = label.length <= 90 && /^(?:추천뉴스|추천 검색어|추천\s*상품|많이 본(?: 뉴스| 기사)?|사람들이 많이 본 뉴스|실시간 랭킹 기사|클립 인기 TOP 랭킹|웹툰 인기 급상승|라이브 이슈|오늘의 핫이슈|이슈체크|오늘의 사건.?사고|오늘의\s*동영상|많이 읽은 기사(?: 종합 연예스포츠)?|문화.?연예|방송.?연예|연예.?스포츠|포토.?영상|구독한 이슈|이슈투데이|ISSUE Today|뉴스\s*&\s*이슈|핫이슈\s*칼럼|Ditta\s*핫이슈|매매신호(?:\s*\(랭킹100\))?|.*이슈NOW.*)$/i.test(label);
      if (!blockedModules.some((blocked) => label === blocked) && !isPressNoiseHeading && !isGenericNoiseHeading) return;
      let node = heading.parentElement;
      let candidate = heading.parentElement;
      for (let depth = 0; node && node !== document.body && depth < 7; depth += 1, node = node.parentElement) {
        const links = [...node.querySelectorAll("a[href]")].filter(looksLikeArticle).length;
        const length = (node.textContent || "").length;
        if (links >= 2 && links <= 40 && length <= 6000) candidate = node;
        if (links >= 4) break;
      }
      candidate?.classList.add("plf-blocked");
    });
  }

  function collectOpenRoots(start) {
    const roots = [];
    const visited = new Set();
    const visit = (scope) => {
      if (!scope || visited.has(scope) || !scope.querySelectorAll) return;
      visited.add(scope);
      roots.push(scope);
      scope.querySelectorAll("*").forEach((element) => {
        if (element.shadowRoot) visit(element.shadowRoot);
      });
    };
    visit(start || document);
    return roots;
  }

  function processFeed(root) {
    hideNoiseSections();
    collectOpenRoots(root || document).forEach((scope) => scope.querySelectorAll("a[href]").forEach(processAnchor));
    if (root instanceof HTMLAnchorElement) processAnchor(root);
  }

  function watchFeed() {
    const observedRoots = new WeakSet();
    const observeRoot = (root) => {
      if (!root || observedRoots.has(root)) return;
      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) scanRoot(node);
          else if (node.parentElement) processFeed(node.parentElement);
        }
      });
      observer.observe(root, { childList: true, subtree: true });
      observedRoots.add(root);
    };
    const scanRoot = (root) => {
      processFeed(root);
      collectOpenRoots(root).forEach(observeRoot);
    };
    scanRoot(document);
    setInterval(() => scanRoot(document), 1250);
  }

  async function start() {
    settings = await getSettings();
    if (!settings.enabled) {
      document.documentElement.classList.remove("plf-article-pending", "plf-article-active", "plf-feed-active", "plf-news-probe");
      return;
    }
    if (document.readyState === "loading") {
      await new Promise((resolve) => document.addEventListener("DOMContentLoaded", resolve, { once: true }));
    }
    const activeArticlePage = isArticlePage || detectStructuredArticle();
    activeArticleDetected = activeArticlePage;
    if (activeArticlePage) {
      document.documentElement.classList.add("plf-article-pending", "plf-article-active");
      const articleSettings = Object.assign({}, settings, isNaverSportsArticlePage
        ? { sportsFeed: true, strictWhitelistOnFeeds: false }
        : { strictWhitelistOnFeeds: true });
      const verdict = core.classify(articleTitle(), document.body?.innerText?.slice(0, 1800), articleSettings);
      if (settings.blockArticlePages && verdict.blocked) {
        const newsHome = isDaum ? "https://news.daum.net/" : isNate ? "https://news.nate.com/" : isNaverSportsArticlePage ? "https://m.sports.naver.com/wfootball/news" : portalHome;
        location.replace(newsHome);
        return;
      }
      document.documentElement.classList.remove("plf-article-pending", "plf-news-probe");
      processFeed(document);
      watchFeed();
      return;
    }
    if (isFeedPage) {
      document.documentElement.classList.remove("plf-news-probe");
      processFeed(document);
      watchFeed();
      return;
    }
    document.documentElement.classList.remove("plf-news-probe");
  }

  start().catch(() => {
    // Fail closed: article pages remain hidden; feed article links remain hidden unless approved.
    document.documentElement.classList.add("plf-filter-error");
  });
})();
