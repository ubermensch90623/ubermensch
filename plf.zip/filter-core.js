(function (root) {
  "use strict";

  const DEFAULTS = Object.freeze({
    enabled: true,
    strictWhitelistOnFeeds: true,
    hideRecommendationFeed: true,
    blockArticlePages: true,
    diagnostics: false,
    sportsFeed: false,
    sportsRumorKeywords: [
      "가능성", "가능성 제기", "전망", "예상", "관측", "추정", "유력", "후보",
      "이적설", "영입설", "방출설", "결별설", "불화설", "루머", "찌라시", "링크",
      "관심 표명", "관심", "눈독", "노린다", "원한다", "검토", "협상 중", "논의 중",
      "추진", "물색", "초읽기", "임박", "공식 발표만 남았다", "HERE WE GO", "할 수도", "될 수도",
      "대체자", "후계자", "시나리오", "행선지", "미래는 불투명"
    ],
    sportsClickbaitKeywords: [
      "충격", "초대박", "대박", "이럴 수가", "기대 폭발", "폭발", "역대급", "최악",
      "미쳤다", "경악", "깜짝", "발칵", "초비상", "굴욕", "날벼락", "대반전",
      "논란", "파문", "스캔들", "감옥 가자", "살인 일정", "항복", "철저히 분석당했나",
      "침묵 부진", "무슨 일", "왜?", "구할까", "이어가나", "뛸까", "남을까", "갈까"
    ],
    sportsFactKeywords: [
      "오피셜", "공식", "확정", "발표", "구단 발표", "입단", "계약 체결", "재계약",
      "이적했다", "영입했다", "경기 결과", "승리", "패배", "무승부", "진출", "탈락",
      "우승", "준우승", "득점", "연속골", "골을", "골망", "헤더 골", "골 터뜨", "도움", "선발", "교체", "결장",
      "부상", "복귀", "대진", "일정", "명단", "순위", "기록", "통계", "전술 분석"
    ],
    sensitiveIdentityKeywords: [
      "중국 노인", "중국인", "중국계", "조선족", "외국인", "이민자", "난민",
      "불법체류자", "다문화 가정", "탈북민", "무슬림"
    ],
    sensitiveBenefitKeywords: [
      "국민연금", "기초연금", "건강보험", "복지", "지원금", "보조금", "세금",
      "혈세", "수급", "혜택", "부양", "보험료", "급여"
    ],
    sensitiveHeatKeywords: [
      "분통", "논란", "반발", "특혜", "역차별", "퍼주기", "무임승차", "가족까지",
      "왜 우리가", "빼앗", "박탈", "분노", "갈등", "혜택만", "먹튀"
    ],
    celebrityLifestyleKeywords: [
      "파격 변신", "빨간 머리", "헤어스타일", "가발", "외모 변화", "근황", "셀카",
      "화보", "다이어트", "체중 감량", "kg 감량", "감량하며", "비주얼", "미모",
      "동안", "몸매", "열애", "결혼", "이혼"
    ],
    customBlockKeywords: [],
    customAllowKeywords: [],
    blockedPress: [
      "OSEN", "스포츠조선", "스포츠서울", "마이데일리", "TV리포트", "스타뉴스",
      "뉴스엔", "엑스포츠뉴스", "텐아시아", "헤럴드POP", "디스패치", "일간스포츠",
      "톱스타뉴스", "위키트리", "스포티비뉴스", "셀럽미디어", "앳스타일", "비하인드"
    ],
    celebrityKeywords: [
      "연예인", "유명인", "유명인사", "셀러브리티", "톱스타", "스포츠 스타", "배우", "영화배우", "탤런트", "감초배우",
      "가수", "뮤지션", "아이돌", "걸그룹", "보이그룹", "방송인", "개그맨", "개그우먼",
      "패션모델", "톱모델", "연예계", "소속사", "팬미팅", "컴백", "데뷔", "시상식", "화보", "예능 출연",
      "드라마 출연", "예능", "예능프로그램", "연예뉴스", "나혼산", "프로게이머", "열애", "결별", "이혼", "재혼", "불륜", "스캔들",
      "근황 공개", "일상 공개", "몸매", "노출", "공항패션"
    ],
    influencerKeywords: [
      "인플루언서", "유튜버", "유튜브 스타", "크리에이터", "BJ", "스트리머", "틱톡커",
      "먹방", "브이로그", "셀럽", "SNS 스타", "팔로워", "구독자"
    ],
    clickbaitKeywords: [
      "충격", "경악", "소름", "발칵", "난리", "역대급", "이럴 수가", "무슨 일", "알고 보니",
      "알고보니", "대체 왜", "결국 터졌다", "눈을 의심", "믿기 힘든", "상상도 못한", "정체는",
      "공개하자", "뒤집어졌다", "미쳤다", "대박", "반응 폭발", "댓글 폭발", "조회수 폭발",
      "실화냐", "초유의", "꼭 봐야", "무조건 봐야", "왜 이러나", "온라인이 뒤집힌",
      "누리꾼 갑론을박", "무슨 말 했길래", "뭐라고 했길래", "난리 난", "난리난",
      "소문이 현실", "파경설", "깜짝 공개", "한 번도 대답 없", "대체 무슨 일",
      "알고보면", "범죄의 섬", "전국 범죄율", "멋짐 가득"
    ],
    investmentHypeKeywords: [
      "오늘장 뭐사지", "뭐 사지", "추천 종목", "급등주", "급등 예상", "매매신호", "매매 신호",
      "대박 종목", "상한가 종목", "종목 공개", "주식 고수", "무료 리딩", "리딩방", "수익률 보장", "대박주"
    ],
    promotionKeywords: [
      "협찬", "공동구매", "공구 오픈", "특가", "핫딜", "최대 할인", "할인 중", "무료 증정",
      "선착순", "한정 판매", "예약 판매", "사전예약", "완판", "품절 대란", "구매 인증",
      "구매 후기", "신제품 출시", "신상 공개", "브랜드 모델", "앰배서더", "프로모션",
      "이벤트 진행", "광고 모델", "PPL", "오늘만", "단독 할인", "파격 할인", "판매 시작"
    ],
    gangKeywords: [
      "조폭", "조직폭력배", "조직폭력", "폭력조직", "행동대장", "조폭 두목", "조폭 보스", "깡패", "보복폭행"
    ],
    celebrityFinanceKeywords: [
      "빌딩 매입", "건물 매입", "건물주 됐다", "억대 건물", "부동산 투자했다", "주식 투자했다",
      "코인 투자했다", "투자처 공개", "투자 비결", "재테크 비결", "주식부자", "부동산부자",
      "시세차익", "수익 인증", "자산 공개", "재산 공개", "보유 주식 공개", "어디에 투자",
      "투자한 곳", "투자 종목 공개", "수익률 공개"
    ],
    disputeKeywords: [
      "개인간 소송", "개인 간 소송", "맞소송", "법정 공방", "고소전", "고발전", "상간 소송",
      "양육권 소송", "재산분할 소송", "소송전", "폭로전", "진실공방", "채무 분쟁", "맞고소",
      "시부모 갈등", "시댁 갈등", "고부갈등", "고부 갈등", "며느리 갈등", "장모 갈등",
      "처가 갈등", "부부 갈등", "부부싸움", "가족 간 갈등", "형제 갈등", "자매 갈등",
      "유산 다툼", "상속 다툼", "재산 다툼", "집안 싸움", "친정 갈등", "금전 거래",
      "돈거래", "돈 거래", "돈 빌려", "빌려준 돈", "빌린 돈", "돈 안 갚", "차용증",
      "돈 문제로", "빚 문제로", "송금 실수", "계모임 갈등", "중고거래 분쟁", "개인 채무"
    ],
    violentCrimeKeywords: [
      "무단침입", "주거침입", "불법침입", "학교 침입", "여고 침입", "여장남자", "여장 남성",
      "테러", "테러범", "테러 위협", "살해", "살해 협박", "살인미수", "흉기난동", "흉기 난동",
      "칼부림", "인질", "폭발물", "폭탄 테러", "총격", "총기난사", "총기 난사", "강도살인",
      "보복범죄", "묻지마 범죄", "암살", "성폭행", "성추행", "납치", "불법촬영"
    ],
    fraudKeywords: [
      "사기 피해", "투자사기", "투자 사기", "보이스피싱", "전세사기", "전세 사기", "로맨스 스캠",
      "누명", "무고", "무고죄", "음해", "허위 고소", "범인으로 몰려", "억울한 옥살이"
    ],
    incidentKeywords: [
      "사망", "숨진", "살인", "살해", "시신", "극단적 선택", "폭행", "흉기", "칼부림", "실종",
      "추락", "참변", "교통사고", "충돌 사고", "화재", "방화", "붕괴", "폭발", "감전", "익사",
      "중상", "부상", "총기사고", "탈영", "스토킹", "벌금", "구형", "피의자", "체포", "검거",
      "구속", "입건", "송치", "현행범", "몰카", "도박", "마약", "유족", "별세", "향년"
    ],
    baseballKeywords: [
      "야구", "프로야구", "KBO", "MLB", "메이저리그", "한국시리즈", "홈런", "타율", "방어율",
      "선발투수", "구원투수", "투수", "포수", "유격수", "외야수", "내야수", "이닝", "안타", "도루",
      "두산 베어스", "LG 트윈스", "롯데 자이언츠", "KIA 타이거즈", "한화 이글스", "삼성 라이온즈",
      "키움 히어로즈", "SSG 랜더스", "NC 다이노스", "KT 위즈"
    ],
    humanInterestKeywords: [
      "암 투병", "희귀병", "난치병", "치매", "조현병", "정신질환", "장애인 아들", "장애인 딸",
      "가족 투병", "사업 실패", "빚더미", "파산", "생활고", "인생역전", "출생의 비밀",
      "성정체성", "양성애", "372일", "매일 달렸다"
    ],
    speechMarkers: [
      "발언", "말했다", "한마디", "주장", "언급", "인터뷰", "SNS", "글 올려", "입장문",
      "사과문", "공개 발언", "생방송에서"
    ],
    controversyMarkers: [
      "논란", "파장", "뭇매", "갑론을박", "발칵", "술렁", "시끌", "반발", "분노", "후폭풍",
      "도마", "사과", "저격", "설전", "공방", "비난", "막말", "실언", "직격", "말폭탄", "신경전"
    ],
    ordinaryPersonMarkers: [
      "A씨", "B씨", "C씨", "일반인", "시민", "주민", "행인", "운전자", "승객", "회사원",
      "직장인", "대학생", "고등학생", "중학생", "초등학생", "한 남성", "한 여성", "10대 남성",
      "20대 남성", "30대 남성", "40대 남성", "50대 남성", "60대 남성", "10대 여성",
      "20대 여성", "30대 여성", "40대 여성", "50대 여성", "60대 여성", "전 연인", "지인", "이웃"
    ],
    arrestKeywords: ["체포", "검거", "구속", "입건", "송치", "붙잡혀", "현행범", "긴급체포", "구속영장"]
  });

  const COMPOUND_ALLOW_RULES = Object.freeze([
    { reason: "ai-productivity", subject: ["AI", "인공지능", "ChatGPT", "챗GPT", "OpenAI", "Gemini", "제미나이", "Claude", "클로드", "NotebookLM", "생산성"], utility: ["출시", "업데이트", "기능", "사용법", "활용법", "활용", "도구", "모델", "API", "에이전트", "업무", "공부", "자동화", "보안", "선정", "교육", "전환"] },
    { reason: "economy-market", subject: ["경제", "금리", "물가", "환율", "증시", "코스피", "코스닥", "채권", "주식", "부동산", "대출", "주담대", "금융", "세금", "은행", "증권사", "보험사", "손보사", "가상자산"], utility: ["전망", "분석", "정책", "인상", "인하", "상승", "하락", "오르", "내리", "마감", "변동", "영향", "지표", "발표", "규제", "개편", "시장", "수익", "수익률", "실적", "공시", "가이드", "급여", "생산성", "과세", "순매수", "순매도"] },
    { reason: "business-industry", subject: ["스타트업", "중소기업", "중견기업", "중기", "中企", "기업금융", "산업", "반도체", "HBM", "수출기업"], utility: ["투자", "육성", "협약", "지원", "실적", "수출", "기술", "생산", "고용", "취업", "채용", "정책", "펀드", "대출", "성장", "교육", "전환", "선정"] },
    { reason: "jobs-exam", subject: ["채용", "취업", "일자리", "청년", "공기업", "금융공기업", "NCS", "경제학", "경영학", "캠코", "한국자산관리공사", "서민금융", "신용회복", "산업인력공단", "시험", "필기"], utility: ["공고", "모집", "지원", "자격", "일정", "접수", "마감", "전형", "합격", "출제", "기출", "채용", "시험", "예산", "교육", "패키지"] },
    { reason: "housing-law", subject: ["전세", "임대차", "보증보험", "HUG", "임차권", "법원", "주거", "복지"], utility: ["신청", "지원", "자격", "절차", "기한", "마감", "개정", "판결", "정책", "보증", "청구", "등기", "지급"] },
    { reason: "local-action", subject: ["수원", "평택", "매탄", "권선", "경기남부"], utility: ["기상청", "시청", "재난문자", "특보", "주의보", "경보", "폭염", "태풍", "호우", "폭우", "대설", "미세먼지", "교통통제", "운행중단", "도로통제", "대피", "채용", "지원사업"] },
    { reason: "health", subject: ["고혈압", "목디스크", "오십견", "회전근개", "건강보험", "의료", "치료", "건강"], utility: ["가이드", "예방", "치료", "진단", "증상", "운동", "급여", "보험", "연구", "권고", "지원"] },
    { reason: "arsenal", subject: ["아스날", "Arsenal"], utility: ["경기", "전술", "부상", "복귀", "선발", "라인업", "영입", "이적", "계약", "공식", "프리미어리그", "챔피언스리그"] },
    { reason: "public-policy", subject: ["정부", "국회", "대통령", "대법원", "헌법재판소", "금융위원회", "금감원", "고용노동부"], utility: ["법안", "법률", "시행", "확정", "예산", "정책", "지원", "제도", "규제", "개편", "판결", "결정", "공고"] },
    { reason: "world-affairs", subject: ["러시아", "우크라이나", "미국", "중국", "EU", "유럽연합", "NATO", "나토"], utility: ["외교", "협상", "휴전", "제재", "관세", "정책", "전쟁", "전선", "무역", "정상회담", "국방", "금리", "경제 영향"] }
  ]);

  const OFFICIAL_MARKERS = ["정부", "경찰청", "소방청", "기상청", "금감원", "금융감독원", "행정안전부", "질병관리청", "시청", "도청", "공식", "재난문자"];
  const ACTION_MARKERS = ["주의보", "경보", "특보", "대피", "통제", "피해 예방", "예방 수칙", "신종 수법", "행동요령", "긴급 안내", "안전 안내"];
  const RISKY_TOKEN_KEYWORDS = new Set(["스타", "사기", "AI", "BJ", "PPL", "EU", "NATO"]);

  function normalize(value) {
    return String(value || "").normalize("NFKC").replace(/\s+/g, " ").trim().toLocaleLowerCase("ko-KR");
  }

  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function hasKeyword(text, keyword) {
    const haystack = normalize(text);
    const needle = normalize(keyword);
    if (!needle) return false;
    const asciiOnly = /^[a-z0-9.+#-]+$/i.test(needle);
    if (asciiOnly || RISKY_TOKEN_KEYWORDS.has(keyword)) {
      const pattern = new RegExp(`(^|[^\\p{L}\\p{N}])${escapeRegExp(needle)}($|[^\\p{L}\\p{N}])`, "iu");
      return pattern.test(haystack);
    }
    return haystack.includes(needle);
  }

  function firstMatch(text, keywords) {
    for (const keyword of keywords || []) if (hasKeyword(text, keyword)) return keyword;
    return null;
  }

  function matchesCompound(text, rule) {
    const subject = firstMatch(text, rule.subject);
    const utility = firstMatch(text, rule.utility);
    return subject && utility ? { subject, utility } : null;
  }

  function classify(title, context, settings) {
    const config = Object.assign({}, DEFAULTS, settings || {});
    const headline = normalize(title);
    const nearby = normalize(context);
    const combined = `${headline} ${nearby}`;
    if (!config.enabled) return { blocked: false, reason: "disabled" };
    if (!headline) return { blocked: true, reason: "unclassified-empty" };

    const customBlock = firstMatch(headline, config.customBlockKeywords);
    if (customBlock) return { blocked: true, reason: "custom-block", match: customBlock };
    const customAllow = firstMatch(headline, config.customAllowKeywords);
    if (customAllow) return { blocked: false, reason: "custom-allow", match: customAllow };

    const official = firstMatch(combined, OFFICIAL_MARKERS);
    const action = firstMatch(headline, ACTION_MARKERS);
    if (official && action) return { blocked: false, reason: "official-safety-alert", match: `${official} + ${action}` };

    const sensitiveIdentity = firstMatch(headline, config.sensitiveIdentityKeywords);
    const sensitiveBenefit = firstMatch(headline, config.sensitiveBenefitKeywords);
    const sensitiveHeat = firstMatch(headline, config.sensitiveHeatKeywords);
    if (sensitiveIdentity && sensitiveBenefit && sensitiveHeat) {
      return {
        blocked: true,
        reason: "identity-benefit-controversy",
        match: `${sensitiveIdentity} + ${sensitiveBenefit} + ${sensitiveHeat}`
      };
    }

    const celebrityLifestyle = firstMatch(headline, config.celebrityLifestyleKeywords);
    if (celebrityLifestyle) {
      return { blocked: true, reason: "celebrity-lifestyle", match: celebrityLifestyle };
    }

    if (config.sportsFeed) {
      const sportsRumor = firstMatch(combined, config.sportsRumorKeywords);
      if (sportsRumor) return { blocked: true, reason: "sports-rumor", match: sportsRumor };
      const sportsClickbait = firstMatch(headline, config.sportsClickbaitKeywords);
      if (sportsClickbait) return { blocked: true, reason: "sports-clickbait", match: sportsClickbait };
      if (/[!?！？]/u.test(headline)) return { blocked: true, reason: "sports-clickbait-punctuation" };
      if (/(?:될까|할까|갈까|남을까|구할까|이어가나|아닐까|어쩌나|가능할까)(?:\s|[?!….'"])*$/u.test(headline)) {
        return { blocked: true, reason: "sports-speculation-question" };
      }
      const sportsFact = firstMatch(combined, config.sportsFactKeywords);
      if (sportsFact) return { blocked: false, reason: "sports-fact", match: sportsFact };
      return { blocked: true, reason: "sports-unverified" };
    }

    for (const rule of COMPOUND_ALLOW_RULES) {
      const match = matchesCompound(headline, rule);
      if (match) return { blocked: false, reason: rule.reason, match: `${match.subject} + ${match.utility}` };
    }

    const categoryChecks = [
      ["celebrity", config.celebrityKeywords],
      ["influencer", config.influencerKeywords],
      ["clickbait", config.clickbaitKeywords],
      ["investment-hype", config.investmentHypeKeywords],
      ["promotion", config.promotionKeywords],
      ["gang", config.gangKeywords],
      ["celebrity-finance", config.celebrityFinanceKeywords],
      ["private-dispute", config.disputeKeywords],
      ["violent-crime", config.violentCrimeKeywords],
      ["fraud-false-charge", config.fraudKeywords],
      ["baseball", config.baseballKeywords],
      ["human-interest", config.humanInterestKeywords]
    ];
    for (const [reason, keywords] of categoryChecks) {
      const match = firstMatch(headline, keywords);
      if (match) return { blocked: true, reason, match };
    }

    const speech = firstMatch(headline, config.speechMarkers);
    const controversy = firstMatch(headline, config.controversyMarkers);
    if (speech && controversy) return { blocked: true, reason: "remark-controversy", match: `${speech} + ${controversy}` };

    const person = firstMatch(headline, config.ordinaryPersonMarkers);
    const arrest = firstMatch(headline, config.arrestKeywords);
    if (person && arrest) return { blocked: true, reason: "ordinary-person-arrest", match: `${person} + ${arrest}` };

    const incident = firstMatch(headline, config.incidentKeywords);
    if (incident) return { blocked: true, reason: "incident", match: incident };

    const press = firstMatch(nearby, config.blockedPress);
    if (press) return { blocked: true, reason: "blocked-press", match: press };

    if (config.strictWhitelistOnFeeds) return { blocked: true, reason: "outside-life-whitelist" };
    return { blocked: false, reason: "neutral" };
  }

  root.PortalLifeFilterCore = {
    DEFAULTS,
    COMPOUND_ALLOW_RULES,
    normalize,
    hasKeyword,
    firstMatch,
    classify
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
