(function () {
  "use strict";
  const defaults = globalThis.PortalLifeFilterCore.DEFAULTS;
  const $ = (id) => document.getElementById(id);
  const splitWords = (value) => [...new Set(value.split(/[\n,]/).map((v) => v.trim()).filter(Boolean))].slice(0, 100);
  const joinWords = (values) => (values || []).join("\n");
  $("version").textContent = `v${chrome.runtime.getManifest().version}`;

  function render(settings) {
    $("enabled").checked = settings.enabled;
    $("strict").checked = settings.strictWhitelistOnFeeds;
    $("hideFeed").checked = settings.hideRecommendationFeed;
    $("blockWords").value = joinWords(settings.customBlockKeywords);
    $("allowWords").value = joinWords(settings.customAllowKeywords);
    $("status").textContent = settings.enabled ? "집중력 보호 중" : "필터 꺼짐";
    $("status").classList.toggle("off", !settings.enabled);
  }

  chrome.storage.sync.get({ portalLifeFilter: defaults }, (result) => {
    render(Object.assign({}, defaults, result.portalLifeFilter || {}));
  });

  $("enabled").addEventListener("change", () => {
    $("status").textContent = $("enabled").checked ? "집중력 보호 중" : "필터 꺼짐";
    $("status").classList.toggle("off", !$("enabled").checked);
  });

  $("save").addEventListener("click", () => {
    const settings = Object.assign({}, defaults, {
      enabled: $("enabled").checked,
      strictWhitelistOnFeeds: $("strict").checked,
      hideRecommendationFeed: $("hideFeed").checked,
      customBlockKeywords: splitWords($("blockWords").value),
      customAllowKeywords: splitWords($("allowWords").value)
    });
    chrome.storage.sync.set({ portalLifeFilter: settings }, () => {
      $("saved").textContent = chrome.runtime.lastError ? "저장 실패" : "저장됨 · 열린 포털을 새로고침하세요";
      if (!chrome.runtime.lastError) render(settings);
    });
  });
})();
